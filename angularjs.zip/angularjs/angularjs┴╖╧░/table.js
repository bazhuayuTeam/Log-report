var app = angular.module('myApp', ['ngRoute']);
var sorts = '';
var clickNum = 0;

function student(id,name,college,specialty,grade,Class,year){
    this.id = id;
    this.name = name;
    this.college = college;
    this.specialty = specialty;
    this.grade = grade;
    this.Class = Class;
    this.year = year;
}
var data =  [
    { id: '11503080301', name: '1', college: '计算机科学与工程学院', specialty: '软件工程', grade: 2015, Class: 3, year: 19 },
    { id: '11501060112', name: '2', college: '经贸学院', specialty: '国际金融与贸易', grade: 2015, Class: 2, year: 21 },
    { id: '11502090423', name: '3', college: '会计学院', specialty: '会计学', grade: 2015, Class: 2, year: 20 },
    { id: '11503080304', name: '4', college: '计算机科学与工程学院', specialty: '软件工程', grade: 2015, Class: 3, year: 19 },
    { id: '11501060115', name: '5', college: '经贸学院', specialty: '国际金融与贸易', grade: 2015, Class: 2, year: 21 },
    { id: '11502090426', name: '6', college: '会计学院', specialty: '会计学', grade: 2015, Class: 2, year: 20 },
    { id: '11503080307', name: '7', college: '计算机科学与工程学院', specialty: '软件工程', grade: 2015, Class: 3, year: 19 },
    { id: '11501060118', name: '8', college: '经贸学院', specialty: '国际金融与贸易', grade: 2015, Class: 2, year: 21 },
    { id: '11502090429', name: '9', college: '会计学院', specialty: '会计学', grade: 2015, Class: 2, year: 20 },
    { id: '11501060110', name: '10', college: '经贸学院', specialty: '国际金融与贸易', grade: 2015, Class: 2, year: 21 },
    { id: '11502090421', name: '11', college: '会计学院', specialty: '会计学', grade: 2015, Class: 2, year: 20 },
    { id: '11503080301', name: '12', college: '计算机科学与工程学院', specialty: '软件工程', grade: 2015, Class: 3, year: 19 }
];

// 通过自定义过滤器换页
app.filter('paging',function(){      //paging 过滤器
  return function(lists,start){     //两个参数 lists 是在 html 里你ng-repeat的原始数据：             //  start 也就是 paging 后面传的参数，即 currentPage*listsPerPage
    return lists.slice(start);     //将原始数据按照 start 分割
  };
});

app.controller('userCtrl', function($scope, $filter) {
$scope.datas = data;

// 新增信息添加到datas中
$scope.addStudent = function() {
        var addId = $scope.usernum;
        var addName = $scope.username;
        var addCollege = $scope.college;
        var addSpecialty = $scope.specialty;
        var addGrade = $scope.grade;
        var addClass = $scope.Class;
        var addYear = $scope.year;
        $scope.datas.push(new student(addId,addName,addCollege,addSpecialty,addGrade,addClass,addYear));
        alert("新增成功！");
    };

    // 关于换页的总页数 当前页 总个数等信息
    $scope.dataNum =  $scope.datas.length;  //获得数据总个数
    $scope.pages = Math.ceil($scope.dataNum/5);         //按照每页显示3个数据，得到总页数
    $scope.pageNum = [];                                //生成页码，在 html里 ng-repeat 出来
    for(var i=0;i<$scope.pages;i++){
      $scope.pageNum.push(i);
    }

    $scope.currentPage = 0;                       //设置当前页是 0
    $scope.listsPerPage = 5;                      //设置每页显示 3 个

    $scope.setPage = function(num){             // 当点击页码数字时执行的函数
      $scope.currentPage = num;                 //将当前页 设置为 页码数
    }

    $scope.prevPage = function(){               //点击上一页执行的函数
          if($scope.currentPage > 0){
              $scope.currentPage--;
          }
      }
     $scope.nextPage = function(){   
             //点击下一页执行的函数
          if ($scope.currentPage < $scope.pages-1){
              $scope.currentPage++;

          }
      }

// 排序
$scope.desc = 0;//默认排序条件升序
$scope.sort = function(){
    clickNum++;
    if(clickNum % 2 == 1)
        $scope.col = 'year';//默认按year列排序
    else
        $scope.col = '';

    $scope.desc = !($scope.desc);
    }

// 全选框
$scope.chkall = false;
$scope.chkAll = function(checked){
        angular.forEach($scope.datas, function(value, key){
        value.checked = checked;
    });
};

// 单选
$scope.$watch('datas', function(nv, ov){
        if(nv == ov){
       return;
   }

    $scope.choseArr = [];
    angular.forEach(
     $filter('filter')(nv, {checked: true}), function(v) {
        $scope.choseArr.push(v.id);
      });
   
          $scope.chkall = $scope.choseArr.length == $scope.datas.length;
        }, true);

// 删除
$scope.deleteInf = function(){
    for(var i = 0; i < $scope.choseArr.length;i++){

        for(var j = 0; j  < $scope.datas.length;j++){
            
            if($scope.choseArr[i] == $scope.datas[j].id){
                $scope.datas.splice(j,1);
                break;
            }
        }
    }

    alert("删除成功！");
}
});

// 路由界面
app.config(['$routeProvider',function ($routeProvider) {
    $routeProvider.
    when('/add', {
        templateUrl: 'add.html',
    }).
    when('/change/:index', {
        templateUrl: 'change.html',
    }).
    when('/view/:index', {
        templateUrl: 'view.html',
    }).
    when('/addConfirm', {
        templateUrl: 'table.html',
    }).
    when('/addCancel', {
        templateUrl: 'table.html',
    }).
    when('/changeConfirm', {
        templateUrl: 'table.html',
    }).
    when('/changeCancel', {
        templateUrl: 'table.html',
    }).
    otherwise({
        templateUrl: 'table.html'
    });
}]);

// 修改之前学生信息
app.controller('DetailController', function($scope,$routeParams) {
    $scope.user= data[$routeParams.index];
    var beforeId = data[$routeParams.index].id;
    var beforeName = data[$routeParams.index].name;
    var beforeCollege = data[$routeParams.index].college;
    var beforeSpecialty = data[$routeParams.index].specialty;
    var beforeGrade = data[$routeParams.index].grade;
    var beforeClass = data[$routeParams.index].Class;
    var beforeYear = data[$routeParams.index].year;

    // 修改取消键
    $scope.clickChangeCancel = function(){
        $scope.user.id = beforeId;
        $scope.user.name = beforeName;
        $scope.user.college = beforeCollege;
        $scope.user.specialty = beforeSpecialty;
        $scope.user.grade = beforeGrade;
        $scope.user.Class = beforeClass;
        $scope.user.year = beforeYear;
    };

    $scope.changeStudent = function(){
        alert("修改成功！");
    }

});

